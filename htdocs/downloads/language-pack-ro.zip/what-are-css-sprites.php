<p>Sprite-urile CSS reprezinta o metoda de a reduce numarul de cereri HTTP facute pentru resursele de imagini referite in site-ul tau. Imaginile sunt combinate intr-o singura imagine cu valori X si Y definite. Utilizand proprietatea CSS <code>background-position</code> imaginile ce o compun sunt atribuite elementelor relevante ale paginii.</p>
<p>Aceasta tehnica poate fi foarte eficienta in perfomanta site-ului, in mod special cand imagini mici, precum icoanele din meniuri, sunt utilizate. Spre exemplu, pagina de start <a href="http://www.yahoo.com/">Yahoo!</a>, utilizeaza aceasta tehnica tocmai cu acest scop.</p>
<h2>Probleme</h2>
<p>Exista cateva probleme de afisare in browser ce trebuie luate in considerare atunci cand utilizezi un sprite CSS.</p>
<h3>Opera</h3>
<p>Opera (cel putin pana in versiunea 9.0) nu va recunoaste o pozitie a fundalului mai mare de 2042px sau mai mica de -2042px, utilizand, implicit, aceasta valoare. Unealta va lua in considerare aceasta problema si va crea o noua coloana in imaginea generata de fiecare data cand limita verticala este atinsa.</p>
<h3>Safari</h3>
<p><a href="http://creativebits.org/webdev/safari_background_repeat_bug_fix">Safari are o problema cu imaginile de fundal repetate.</a>. Din fericire, aceasta problema poate fi foarte simplu rezolvata specificand o valoarea destul de mare a marginii orizontale (configurabila).</p>
<h2>De citit</h2>
<p><a href="http://www.alistapart.com/">A List Apart</a> a publicat un articol intitulat <a href="http://www.alistapart.com/articles/sprites">Sprite-uri CSS: Sarutul mortii in taierea imaginilor</a> care explica conceptul ce sta la baza sprite-urilor CSS. Daca utilizezi pentru prima data aceasta tehnica, iti recomandam sa arunci o privire pe <a href="http://www.alistapart.com/">A List Apart</a>.</p>
