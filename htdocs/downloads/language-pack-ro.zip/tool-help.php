<p>Aceasta unealta iti permite sa automatizezi procesul de generare a unui Sprite CSS. Ofera-i o simpla arhiva ZIP care sa contina 2 sau mai multe imagini (GIF, PNG sau JPG) si ea iti va genera o imagine sprite corespunzatoare regulilor CSS targetate pentru a afisa fiecare imagine componenta.</p>
<h2>Optiuni</h2>
<p>Unealta are o serie de optiuni pentru configurarea caracteristicilor imaginii sprite generate si a stilului CSS pentru o mai buna potrivire cu setarile site-ului tau. Aceste optiuni sunt detaliate mai jos:</p>
<h3>Redimensionare imagini sursa</h3>
<dl>
   <dt>Lungime &amp; Inaltime</dt>
   <dd>Daca lungimea sau inaltimea imaginilor sursa vor fi setate mai jos de 100%, acestea vor fi reduse in marime inainte de a fi copiate in imaginea generata. Unealta nu te va lasa sa specifici o valoarea mai mare de 100% deoarece va rezulta o reducere a calitatii imaginii. Valoarea initiala pentru lungime si inaltime este 100% (neredimensionata)
   </dd>
</dl>
<h3>Imaginile duplicate</h3>
<dl>
   <dt>Ignora imaginile duplicate</dt>
   <dd>Imaginile duplicate sunt copiate in imaginea generata si sunt create reguli individuale CSS pentru fiecare duplicat.</dd>
   <dt> Sterge imaginile duplicate dar combina clasele</dt>
   <dd>Unealta va compara continutul MD5 a fiecarei imagini pentru a determina cu exactitate care sunt imaginile duplitate din arhiva ZIP. Aceste duplicate sunt abandonate si regulile CSS corespunzatoare vor fi combinate intr-o singura regula.
   </dd>
</dl>
<h3>Optiuni de afisare Sprite</h3>
<dl>
   <dt>Margine orizontala</dt>
   <dd>Acesta determina spatiul orizontal dintre randuri la afisare. Aceasta valoare trebuie sa fie destul de mare, luand in considerare <a href="http://creativebits.org/webdev/safari_background_repeat_bug_fix">problema repetarii fundalului in Safari</a>. Iti sugeram sa ramai la ramai la valoarea initiala.</dd>
   <dt>Margine verticala</dt>
   <dd>Aceasta determina valoarea spatiului vertical dintre fiecare imagine consecutiva. Valoarea optiunii trebuie sa tina cont si de posibila crestere a marimii fontului de catre utilizator. In general, recomandam sa oferi posibilitatea utilizatorului de a dubla marimea fontului afisat inainte ca urmatoarea imagine din secventa sa fie vizibila.</dd>
   <dt>Intrerupe coloanele pentru a repara o problema in Opera</dt>
   <dd>Opera 9.0 si versiunile inferioare au o problema care afecteaza marginea fundalului CCS mai mica de -2042px. Toate valorile mai mici decat aceasta sunt interpretate exact -2042px. Selectand aceasta optiune, Generatorul de Sprite CSS va crea o noua coloana de fiecare data cand marginea verticala atinge valoarea de -2000px.</dd>
   <dt>Culoare fundal</dt>
   <dd>Seteaza o culoare de fundal pentru imaginea generata. Aceast camp utilizeaza o valoare hexazecimala a culorii din 6 digiti. Lasata necompletata si cu formatul de generare setat ca GIF sau PNG, fundalul va fi transparent.</dd>
   <dt>Formatul de iesire</dt>
   <dd>Suporta formatele GIF, PNG si JPG. Formatele GIF si PNG pot avea fundalul transparent. Formatul initial este PNG.</dd>
   <dt>Numarul de culori</dt>
   <dd>Restrictioneaza numarul de culori utilizat in formatul de iesire generat oentru a reduce marimea acestuia. Aceasta optiune este aplicabila la formatele PNG si GIF.</dd>
   <dt>Calitate imaginii</dt>
   <dd>Specifica calitatea imaginii generate in procente. Aceasta optiune este valabila numai pentru formatul JPEG.</dd>
   <dt>Compresie imagine cu OptiPNG </dt>
   <dd>Utilizata, fisierul imagine generat va fi comprimat cu <a href="http://optipng.sourceforge.net/">OptiPNG</a> pentru a-i reduce marimea. Adesea, marimea este redusa la jumatate din initial. Aceasta optiune este valabila numai pentru formatul PNG.</dd>
</dl>
<h3>Optiuni de generare CSS</h3>
<dl>
   <dt>Prefix CSS</dt>
   <dd>Fiecare regula CSS generata este precedata de sufixul precizat. Suporta prefixele id de baza si selectorii de clasa. Urmatoarele caractele sunt permise - <em>a-z</em>, <em>0-9</em>, <em>_</em>, <em>-</em>, <em>#</em> si <em>.</em></dd>
   <dt>Potrivirea tiparului de nume a fisierului</dt>
   <dd>orice expresie regulara poate fi utilizata. Inchide intre paranteze rotunde sectiunea care doresti sa fie extrasa din numele fiecarei imagini. Acestea vor fi utilizate ca fundament pentru numele claselor.</dd>
   <dt>Prefixul clasei</dt>
   <dd>Textul introdus va fi utilizat inaintea numelui fiecare clase CSS generate. In mod particular, aceasta optiune este importanta de utilizat atunci cand numele clasei generate va incepe cu un numar, ceea ce va genera un selector invalid (asa cum este definit in recomandarile W3C). Urmatoarele caracte sunt permise - <em>a-z</em>, <em>0-9</em>, <em>_</em> si <em>-</em>. Valoarea prefixului furnizat nu poate incepe cu un numar.</dd>
   <dt>Sufix CSS</dt>
   <dd>Valoarea introdusa va fi adaugata la sfarsitul fiecarei regului CSS. &quot;Sufixul CSS&quot; utilizeaza acelasi tip de caractere ca si  &quot;Clasa prefix&quot;.</dd>
</dl>
